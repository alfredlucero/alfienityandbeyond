Alfred Lucero
ID:604251044

Nicandro Vergara
ID: 804346386

Alfred Lucero handled most of the UI and design of the website in addition to creating
multiple pages to add movies/directors/actors to the database. Nicandro Vergara aided with searching,
showing actor/movie info., and adding reviews to the database. Also, we collaborated over github,
but we are still adapting to git and need to improve on using the shell to contribute to repositories
more efficiently. We ran into some struggles using the github UI as well as MySQL meticulous syntax for
submitting in queries. We worked incrementally and used echo statements to help with debugging our code
onto the php pages. Since we split up our movie website database amongst php pages, we were better able to
split up the work and maximize our efficiency.
For test cases, Nicandro Vergara created the t1-t5 test files, and Alfred Lucero replayed them in order to test
our web database through Selenium. We initially had troubles with finding the correct base URL and we discovered
that the base URL must match the project spec after it is unzipped so:
http://localhost:1438/~cs143/604251044/www/home.php
OR
http://localhost:1438/~cs143/604251044/www/review.php,
assuming that one unzips the P1C.zip file in the first directory of .../~cs143 (it is within ~/www)
so that there is a proper base URL that tracks all of our files within the UID folder.

