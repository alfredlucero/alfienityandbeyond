<html>
	<head>
		<style type="text/css">
			#footer {
				background-color:#006699;
				color:white;
				clear:both;
				text-align:center;
				padding:5px;
			}
		</style>
	</head>

	<body>
		<div id="footer">
			Copyright menteMDB. CS143 Project 1C: Alfred Lucero ID:604251044 Nicandro Vergara ID:804346386
		</div>
	</body>
</html>